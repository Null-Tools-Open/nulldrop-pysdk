# NullDrop Python SDK

A simple Python wrapper for the NullDrop file hosting API (v1).

## Install (local)

```bash
pip install .
